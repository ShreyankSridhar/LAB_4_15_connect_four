import random


class AI:
    def choose_column(self, board, me="O", opponent="X"):
        # Find all columns that are not full.
        legal = [
            c for c in range(7)
            if board.grid[0][c] == "."
        ]

        if not legal:
            return None

        # Check whether the AI can win immediately.
        for col in legal:
            row = board.drop(col, me)
            if row is not None:
                wins = board.winner(me)
                board.grid[row][col] = "."
                if wins:
                    return col

        # Block the opponent's immediate winning move.
        for col in legal:
            row = board.drop(col, opponent)
            if row is not None:
                wins = board.winner(opponent)
                board.grid[row][col] = "."
                if wins:
                    return col

        # No immediate win or block: choose a legal move.
        return random.choice(legal)
